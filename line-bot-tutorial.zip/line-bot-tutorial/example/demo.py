# This Python file uses the following encoding: utf-8
import os, sys
from FinMind.Data import Load
from FinMind.Mining import Mind
import datetime
import pandas as pd
import requests
import re

#Variables-------------------------------------------------------------------
date = str( datetime.datetime.now().date() - datetime.timedelta(30) )
date2 = str( datetime.datetime.now().date() - datetime.timedelta(200) )
date3 = str( datetime.datetime.now().date() - datetime.timedelta(120) )
date_now = str( datetime.datetime.now().date() - datetime.timedelta(7) )
#Sub Functions---------------------------------------------------------------
def fetch_table(url):
    """
    fetch table from the Internet
    Args:
        url: website url
    Return:
        pd_table : pandas table
    """


    # pretend to be the chrome brower to solve the forbidden problem
    header = {
      "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.75 Safari/537.36",
      "X-Requested-With": "XMLHttpRequest"
    }
    html_text = requests.get(url, headers=header)

    # to solve garbled text
    html_text.encoding =  html_text.apparent_encoding
    pd_table = pd.read_html(html_text.text)[0]
    # 'Connection':'close' need be set or connection will be refused
    requests.get(url=url, headers={'Connection':'close'})
    return pd_table

def store_csv():
    """
    Store the information to csv file
    """
    url_stock = "http://isin.twse.com.tw/isin/C_public.jsp?strMode=2"
    url_otc = "http://isin.twse.com.tw/isin/C_public.jsp?strMode=4"
    stock_table = fetch_table(url_stock)
    stock_table.to_csv("stock_name.csv",index=None,encoding="utf_8_sig")
    #otc_table = fetch_table(url_otc)
    #otc_table.to_csv("otc_name.csv",index=None,encoding="utf_8_sig")

def extract_code(index_range,csv_string):
    """
    extract code from pandas data frame
    Args:
        index_range: a list which length is 2, containing start and end index
        csv_string : the name to the csv file

    Return:
        code_list: a list contain stock code
    """
    code_list = []
    table = pd.read_csv(csv_string)

    start = index_range[0]
    end  = index_range[1]

    for i in range(start,end):
        string = table.iloc[i][0]
        pattern = "\d*"
        code = re.compile(pattern).findall(string)[0]
        code_list.append(code)

    return code_list
#--------------------------------------------------------------

#1. collect all of stock code
#store_csv()
#stock_code_list = extract_code([2,918],"stock_name.csv")
#print ("The length of stock:",len(stock_code_list))


#2.
def test():

    #cus_stockarray = stock_code_list
    #, '1213'
    #
    #cus_stockarray = ['1101', '1102', '1103', '1104', '1108', '1109', '1110', '1201', '1203', '1210', '1215', '1216', '1217', '1218', '1219', '1220', '1225', '1227', '1229', '1231', '1232', '1233', '1234', '1235', '1236', '1256', '1262', '1301', '1303', '1304', '1305', '1307', '1308', '1309', '1310', '1312', '1313', '1314', '1315', '1316', '1319', '1321', '1323', '1324', '1325', '1326', '1337', '1338', '1339', '1340', '1341', '1402', '1409', '1410', '1413', '1414', '1416', '1417', '1418', '1419', '1423', '1432', '1434', '1435', '1436', '1437', '1438', '1439', '1440', '1441', '1442', '1443', '1444', '1445', '1446', '1447', '1449', '1451', '1452', '1453', '1454', '1455', '1456', '1457', '1459', '1460', '1463', '1464', '1465', '1466', '1467', '1468', '1470', '1471', '1472', '1473', '1474', '1475', '1476', '1477', '1503', '1504', '1506', '1507', '1512', '1513', '1514', '1515', '1516', '1517', '1519', '1521', '1522', '1524', '1525', '1526', '1527', '1528', '1529', '1530', '1531', '1532', '1533', '1535', '1536', '1537', '1538', '1539', '1540', '1541', '1558', '1560', '1568', '1582', '1583', '1587', '1589', '1590', '1592', '1598', '1603', '1604', '1605', '1608', '1609', '1611', '1612', '1614', '1615', '1616', '1617', '1618', '1626', '1701', '1702', '1707', '1708', '1709', '1710', '1711', '1712', '1713', '1714', '1717', '1718', '1720', '1721', '1722', '1723', '1724', '1725', '1726', '1727', '1730', '1731', '1732', '1733', '1734', '1735', '1736', '1737', '1760', '1762', '1773', '1776', '1783', '1786', '1789', '1802', '1805', '1806', '1808', '1809', '1810', '1817', '1902', '1903', '1904', '1905', '1906', '1907', '1909', '2002', '2006', '2007', '2008', '2009', '2010', '2012', '2013', '2014', '2015', '2017', '2020', '2022', '2023', '2024', '2025', '2027', '2028', '2029', '2030', '2031', '2032', '2033', '2034', '2038', '2049', '2059', '2062', '2069', '2101', '2102', '2103', '2104', '2105', '2106', '2107', '2108', '2109', '2114', '2115', '2201', '2204', '2206', '2207', '2208', '2227', '2228', '2231', '2233', '2236', '2239', '2243', '2301', '2302', '2303', '2305', '2308', '2312', '2313', '2314', '2316', '2317', '2321', '2323', '2324', '2327', '2328', '2329', '2330', '2331', '2332', '2337', '2338', '2340', '2342', '2344', '2345', '2347', '2348', '2349', '2351', '2352', '2353', '2354', '2355', '2356', '2357', '2358', '2359', '2360', '2362', '2363', '2364', '2365', '2367', '2368', '2369', '2371', '2373', '2374', '2375', '2376', '2377', '2379', '2380', '2382', '2383', '2385', '2387', '2388', '2390', '2392', '2393', '2395', '2397', '2399', '2401', '2402', '2404', '2405', '2406', '2408', '2409', '2412', '2413', '2414', '2415', '2417', '2419', '2420', '2421', '2423', '2424', '2425', '2426', '2427', '2428', '2429', '2430', '2431', '2433', '2434', '2436', '2438', '2439', '2440', '2441', '2442', '2443', '2444', '2448', '2449', '2450', '2451', '2453', '2454', '2455', '2456', '2457', '2458', '2459', '2460', '2461', '2462', '2464', '2465', '2466', '2467', '2468', '2471', '2472', '2474', '2476', '2477', '2478', '2480', '2481', '2482', '2483', '2484', '2485', '2486', '2488', '2489', '2491', '2492', '2493', '2495', '2496', '2497', '2498', '2499', '2501', '2504', '2505', '2506', '2509', '2511', '2514', '2515', '2516', '2520', '2524', '2527', '2528', '2530', '2534', '2535', '2536', '2537', '2538', '2539', '2540', '2542', '2543', '2545', '2546', '2547', '2548', '2597', '2601', '2603', '2605', '2606', '2607', '2608', '2609', '2610', '2611', '2612', '2613', '2614', '2615', '2616', '2617', '2618', '2630', '2633', '2634', '2636', '2637', '2642', '2701', '2702', '2704', '2705', '2706', '2707', '2712', '2722', '2723', '2727', '2731', '2739', '2748', '2801', '2809', '2812', '2816', '2820', '2823', '2832', '2834', '2836', '2838', '2841', '2845', '2849', '2850', '2851', '2852', '2855', '2867', '2880', '2881', '2882', '2883', '2884', '2885', '2886', '2887', '2888', '2889', '2890', '2891', '2892', '2897', '2901', '2903', '2904', '2905', '2906', '2908', '2910', '2911', '2912', '2913', '2915', '2923', '2929', '2936', '2939', '3002', '3003', '3004', '3005', '3006', '3008', '3010', '3011', '3013', '3014', '3015', '3016', '3017', '3018', '3019', '3021', '3022', '3023', '3024', '3025', '3026', '3027', '3028', '3029', '3030', '3031', '3032', '3033', '3034', '3035', '3036', '3037', '3038', '3040', '3041', '3042', '3043', '3044', '3045', '3046', '3047', '3048', '3049', '3050', '3051', '3052', '3054', '3055', '3056', '3057', '3058', '3059', '3060', '3062', '3090', '3094', '3130', '3149', '3164', '3167', '3189', '3209', '3229', '3231', '3257', '3266', '3296', '3305', '3308', '3311', '3312', '3321', '3338', '3346', '3356', '3376', '3380']#
    #cus_stockarray =['3406', '3413', '3416', '3419', '3432', '3437', '3443', '3450', '3454', '3481', '3494', '3501', '3504', '3515', '3518', '3528', '3530', '3532', '3533', '3535', '3536', '3545', '3550', '3557', '3563', '3576', '3583', '3588', '3591', '3593', '3596', '3605', '3607', '3617', '3622', '3645', '3653', '3661', '3665', '3669', '3673', '3679', '3682', '3686', '3694', '3698', '3701', '3702', '3703', '3704', '3705', '3706', '3708', '3711', '3712', '4104', '4106', '4108', '4119', '4133', '4137', '4141', '4142', '4144', '4148', '4155', '4164', '4190', '4306', '4414', '4426', '4438', '4526', '4532', '4536', '4540', '4545', '4551', '4552', '4555', '4557', '4560', '4562', '4564', '4566', '4571', '4572', '4576', '4720', '4722', '4725', '4737', '4739', '4746', '4755', '4763', '4764', '4766', '4807', '4904', '4906', '4912', '4915', '4916', '4919', '4927', '4930', '4934', '4935', '4938', '4942', '4943', '4952', '4956', '4958', '4960', '4961', '4967', '4968', '4976', '4977', '4989', '4994', '4999', '5007', '5203', '5215', '5225', '5234', '5243', '5258', '5259', '5264', '5269', '5283', '5284', '5285', '5288', '5305', '5388', '5434', '5469', '5471', '5484', '5515', '5519', '5521', '5522', '5525', '5531', '5533', '5534', '5538', '5607', '5608', '5706', '5871', '5876', '5880', '5906', '5907', '6005', '6024', '6108', '6112', '6115', '6116', '6117', '6120', '6128', '6131', '6133', '6136', '6139', '6141', '6142', '6152', '6153', '6155', '6164', '6165', '6166', '6168', '6172', '6176', '6177', '6183', '6184', '6189', '6191', '6192', '6196', '6197', '6201', '6202', '6205', '6206', '6209', '6213', '6214', '6215', '6216', '6224', '6225', '6226', '6230', '6235', '6239', '6243', '6251', '6257', '6269', '6271', '6277', '6278', '6281', '6282', '6283', '6285', '6288', '6289', '6405', '6409', '6412', '6414', '6415', '6416', '6431', '6442', '6443', '6449', '6451', '6452', '6456', '6464', '6477', '6504', '6505', '6525', '6531', '6533', '6541', '6552', '6558', '6573', '6579', '6581', '6582', '6591', '6605', '6625', '6641', '6655', '6666', '6668', '6669', '6670', '6671', '6672', '6674', '8011', '8016', '8021', '8028', '8033', '8039', '8046', '8070', '8072', '8081', '8101', '8103', '8104', '8105', '8110', '8112', '8114', '8131', '8150', '8163', '8201', '8210', '8213', '8215', '8222', '8249', '8261', '8271', '8341', '8367', '8374', '8404', '8411', '8422', '8427', '8429', '8442', '8443', '8454', '8462', '8463', '8464', '8466', '8467', '8473', '8478', '8480', '8481', '8482', '8488', '8497', '8499', '8926', '8940', '8996', '9802', '9902', '9904', '9905', '9906', '9907', '9908', '9910', '9911', '9912', '9914', '9917', '9918', '9919', '9921', '9924', '9925', '9926']
    #print(cus_stockarray)
    #cus_stockarray = ['2439']
    #
    #
    cus_stockarray   = []
    #, '1417'
    #, '2049'
    #, '1528'
    #this line finished, transfer to A
    #cus_stockarray_1 = ['1101', '1102', '1103', '1104', '1108', '1109', '1110', '1201', '1203', '1210', '1215', '1216', '1217', '1218', '1219', '1220', '1227', '1229', '1231', '1232', '1233', '1234', '1236', '1256', '1301', '1303', '1304', '1305', '1307', '1308', '1309', '1310', '1312', '1313', '1314', '1315', '1316', '1319', '1321', '1323', '1325', '1326', '1337', '1338', '1339', '1340', '1341', '1402', '1409', '1410', '1413', '1414', '1416', '1423', '1432', '1434', '1435', '1436', '1437', '1438', '1439', '1440', '1441', '1442', '1443', '1444', '1445', '1446', '1447', '1451', '1452', '1453', '1455', '1457', '1459', '1460', '1463', '1464', '1465' ]
    #cus_stockarray_1 = ['1467', '1468', '1471', '1472', '1473', '1474', '1476', '1477', '1503', '1504', '1506', '1507', '1513', '1514', '1515', '1517', '1519', '1521', '1522', '1524', '1525', '1526', '1527', '1531', '1532', '1533', '1535', '1536', '1537', '1539', '1540', '1541', '1558', '1560', '1568', '1582', '1589', '1590', '1592', '1598', '1604', '1605', '1608', '1609', '1611', '1612', '1614', '1615', '1616', '1618', '1626', '1701', '1702', '1707', '1708', '1709', '1710', '1711', '1712', '1714', '1717', '1718', '1720', '1721', '1722', '1723', '1724', '1725', '1727', '1730', '1731', '1733', '1734', '1736', '1737', '1760', '1762', '1773', '1783', '1786', '1789', '1802', '1806', '1808', '1809', '1810', '1817', '1902', '1904', '1905', '1906', '1907', '1909', '2002', '2006', '2007', '2009', '2010', '2012', '2013', '2014', '2015', '2017', '2020', '2022', '2023', '2024', '2025', '2027', '2028', '2029', '2030', '2031', '2032', '2033', '2034', '2038', '2059', '2062', '2069', '2101', '2102', '2103', '2104', '2105', '2106', '2107', '2108', '2109', '2114', '2115', '2201', '2204', '2206', '2207', '2208', '2227', '2228', '2231', '2239', '2243', '2301', '2302', '2303', '2305', '2308', '2312', '2313', '2314', '2316', '2317', '2323', '2324', '2327', '2328', '2329', '2330', '2331', '2332', '2337', '2338', '2340', '2342', '2344', '2345', '2347', '2348', '2349', '2351', '2352', '2353', '2354', '2355', '2356', '2357', '2358', '2359', '2360', '2362', '2363', '2365', '2367', '2368', '2369', '2371', '2373', '2374', '2375', '2376', '2377', '2379', '2380', '2382', '2383', '2385', '2387', '2388', '2390', '2392', '2393', '2395', '2397', '2399', '2401', '2402', '2404', '2405', '2406', '2408', '2409', '2412', '2413', '2414', '2415', '2417', '2419', '2420', '2421', '2423', '2425', '2426', '2427', '2428', '2430', '2431', '2433', '2436', '2438', '2439', '2441', '2442', '2443', '2444', '2448', '2449', '2450', '2451', '2453', '2454', '2455', '2456', '2457', '2458', '2459', '2460', '2461', '2462', '2464', '2465', '2466', '2467', '2468', '2471', '2472', '2474', '2476', '2477', '2478', '2480', '2481', '2483', '2484', '2485', '2486', '2488', '2489', '2492', '2493', '2495', '2497', '2498', '2499', '2501', '2504', '2505', '2506', '2509', '2511', '2514', '2515', '2516', '2520', '2524', '2527', '2528', '2530', '2534', '2535', '2536', '2537', '2538', '2539', '2542', '2543', '2545', '2546', '2547', '2548', '2597', '2601', '2603', '2605', '2606', '2607', '2608', '2609', '2610', '2611', '2612', '2613', '2614', '2615', '2616', '2617', '2618', '2630', '2633', '2634', '2636', '2637', '2642', '2701', '2702', '2704', '2705', '2706', '2707', '2723', '2727', '2731', '2739', '2748', '2801', '2809', '2812', '2816', '2820', '2823', '2832', '2834', '2836', '2838', '2841', '2845', '2849', '2850', '2851', '2852', '2855', '2867', '2880', '2881', '2882', '2883', '2884', '2885', '2886', '2887', '2888', '2889', '2890', '2891', '2892', '2897', '2901', '2903', '2904', '2905', '2906', '2908', '2911', '2912', '2913', '2915', '2923', '2929', '3002', '3003', '3004', '3005', '3006', '3008', '3010', '3011', '3013', '3014', '3015', '3016', '3017', '3018', '3019', '3021', '3022', '3023', '3024', '3025', '3026', '3027', '3028', '3029', '3030', '3031', '3032', '3033', '3034', '3035', '3036', '3037', '3038', '3040', '3041', '3042', '3043', '3044', '3045', '3046', '3047', '3048', '3049', '3050', '3051', '3052', '3056', '3057', '3058', '3059', '3060', '3062', '3090', '3094', '3149', '3164', '3167', '3189', '3209', '3229', '3231', '3257', '3266', '3296', '3305', '3311', '3312', '3321', '3338', '3346', '3356', '3376', '3380', '3383']
    #cus_stockarray_1 = ['2603', '2605', '2606', '2607', '2608', '2609', '2610', '2611', '2612', '2613', '2614', '2615', '2616', '2617', '2618', '2630', '2633', '2634', '2636', '2637', '2642', '2701', '2702', '2704', '2705', '2706', '2707', '2723', '2727', '2731', '2739', '2748', '2801', '2809', '2812', '2816', '2820', '2823', '2832', '2834', '2836', '2838', '2841', '2845', '2849', '2850', '2851', '2852', '2855', '2867', '2880', '2881', '2882', '2883', '2884', '2885', '2886', '2887', '2888', '2889', '2890', '2891', '2892', '2897', '2901', '2903', '2904', '2905', '2906', '2908', '2911', '2912', '2913', '2915', '2923', '2929', '3002', '3003', '3004', '3005', '3006', '3008', '3010', '3011', '3013', '3014', '3015', '3016', '3017', '3018', '3019', '3021', '3022', '3023', '3024', '3025', '3026', '3027', '3028', '3029', '3030', '3031', '3032', '3033', '3034', '3035', '3036', '3037', '3038', '3040', '3041', '3042', '3043', '3044', '3045', '3046', '3047', '3048', '3049', '3050', '3051', '3052', '3056', '3057', '3058', '3059', '3060', '3062', '3090', '3094', '3149', '3164', '3167', '3189', '3209', '3229', '3231', '3257', '3266', '3296', '3305', '3311', '3312', '3321', '3338', '3346', '3356', '3376', '3380', '3383']
    cus_stockarray_A = ['1101', '1102', '1301', '1303', '1326', '1402']
    cus_stockarray_B = ['2027', '2301', '2324', '2327', '2344', '2356', '2382', '2409', '2439', '2458', '2492']
    cus_stockarray_C = ['2886', '2890', '3231']
    cus_stockarray_D = ['4927', '4938']
    cus_stockarray_E = ['6269']
    #cus_stockarray_A = ['1101', '1102', '1103', '1104', '1234', '1301', '1303', '1305', '1310', '1316', '1323', '1326', '1402', '1416', '1434', '1436', '1451', '1452', '1457', '1463', '1521', '1524', '1527', '1532', '1537', '1539', '1540', '1558', '1560', '1582', '1604', '1710', '1712', '1725', '1737', '1808', '1817', '1904', '1907', '2006', '2010', '2012', '2015', '2020', '2027', '2030', '2031', '2034', '2108', '2114']
    #cus_stockarray_1 = ['2115', '2201', '2204', '2206', '2207', '2208', '2227', '2228', '2231', '2239', '2243', '2301', '2302', '2303', '2305', '2308', '2312', '2313', '2314', '2316', '2317', '2323', '2324', '2327', '2328', '2329', '2330', '2331', '2332', '2337', '2338', '2340', '2342', '2344', '2345', '2347', '2348', '2349', '2351', '2352', '2353', '2354', '2355', '2356', '2357', '2358', '2359', '2360', '2362', '2363', '2365', '2367', '2368', '2369', '2371', '2373', '2374', '2375', '2376', '2377', '2379', '2380', '2382', '2383', '2385', '2387', '2388', '2390', '2392', '2393', '2395', '2397', '2399', '2401', '2402', '2404', '2405', '2406', '2408', '2409', '2412', '2413', '2414', '2415', '2417', '2419', '2420', '2421', '2423', '2425', '2426', '2427', '2428', '2430', '2431', '2433', '2436', '2438', '2439', '2441', '2442', '2443', '2444', '2448', '2449', '2450', '2451', '2453', '2454', '2455', '2456', '2457', '2458', '2459', '2460', '2461', '2462', '2464', '2465', '2466', '2467', '2468', '2471', '2472', '2474', '2476', '2477', '2478', '2480', '2481', '2483', '2484', '2485', '2486', '2488', '2489', '2492', '2493', '2495', '2497', '2498', '2499', '2501', '2504', '2505', '2506', '2509', '2511', '2514', '2515', '2516', '2520', '2524', '2527', '2528', '2530', '2534', '2535', '2536', '2537', '2538', '2539', '2542', '2543', '2545', '2546', '2547', '2548', '2597', '2601', '2603', '2605', '2606', '2607', '2608', '2609', '2610', '2611', '2612', '2613', '2614', '2615', '2616', '2617', '2618', '2630', '2633', '2634', '2636', '2637', '2642', '2701', '2702', '2704', '2705', '2706', '2707', '2723', '2727', '2731', '2739', '2748', '2801', '2809', '2812', '2816', '2820', '2823', '2832', '2834', '2836', '2838', '2841', '2845', '2849', '2850', '2851', '2852', '2855', '2867', '2880', '2881', '2882', '2883', '2884', '2885', '2886', '2887', '2888', '2889', '2890', '2891', '2892', '2897', '2901', '2903', '2904', '2905', '2906', '2908', '2911', '2912', '2913', '2915', '2923', '2929', '3002', '3003', '3004', '3005', '3006', '3008', '3010', '3011', '3013', '3014', '3015', '3016', '3017', '3018', '3019', '3021', '3022', '3023', '3024', '3025', '3026', '3027', '3028', '3029', '3030', '3031', '3032', '3033', '3034', '3035', '3036', '3037', '3038', '3040', '3041', '3042', '3043', '3044', '3045', '3046', '3047', '3048', '3049', '3050', '3051', '3052', '3056', '3057', '3058', '3059', '3060', '3062', '3090', '3094', '3149', '3164', '3167', '3189', '3209', '3229', '3231', '3257', '3266', '3296', '3305', '3311', '3312', '3321', '3338', '3346', '3356', '3376', '3380', '3383']
    #cus_stockarray_B = ['3090', '3164', '3209', '3231', '3296', '3346']
    #cus_stockarray_1 = ['3406', '3413', '3416', '3419', '3432', '3437', '3443', '3450', '3454', '3481', '3494', '3501', '3504', '3515', '3518', '3528', '3530', '3532', '3533', '3535', '3536', '3545', '3550', '3557', '3563', '3576', '3583', '3588', '3591', '3593', '3596', '3605', '3607', '3617', '3622', '3645', '3653', '3661', '3665', '3669', '3673', '3679', '3682', '3686', '3694', '3698', '3702', '3703', '3704', '3705', '3706', '3708', '3711', '3712', '4104', '4106', '4108', '4119', '4133', '4137', '4141', '4142', '4144', '4148', '4155', '4164', '4190', '4306', '4414', '4426', '4438', '4526', '4532', '4536', '4540', '4545', '4551', '4552', '4555', '4557', '4560', '4564', '4566', '4720', '4722', '4725', '4737', '4739', '4746', '4755', '4763', '4764', '4766', '4904', '4906', '4912', '4915', '4916', '4919', '4927', '4930', '4934', '4935', '4938', '4942', '4943', '4952', '4956', '4958', '4960', '4961', '4967', '4968', '4976', '4977', '4989', '4994', '4999', '5007', '5203', '5215', '5225', '5234', '5243', '5258', '5264', '5269', '5283', '5284', '5285', '5288', '5305', '5388', '5434', '5471', '5484', '5515', '5519', '5521', '5522', '5525', '5531', '5533', '5534', '5538', '5607', '5608', '5706', '5871', '5876', '5880', '5907', '6005', '6024', '6108', '6112', '6115', '6116', '6120', '6128', '6133', '6136', '6139', '6141', '6142', '6152', '6155', '6164', '6165', '6166', '6168', '6172', '6176', '6177', '6183', '6184', '6189', '6191', '6192', '6196', '6197', '6201', '6202', '6205', '6206', '6209', '6213', '6214', '6215', '6216', '6224', '6226', '6230', '6235', '6239', '6243', '6251', '6257', '6269', '6271', '6277', '6278', '6281', '6282', '6283', '6285', '6288', '6289', '6409', '6412', '6414', '6415', '6416', '6431', '6442', '6443', '6449', '6451', '6452', '6456', '6477', '6504', '6505', '6525', '6531', '6533', '6541', '6552', '6558', '6573', '6579', '6581', '6591', '6605', '6655', '6666', '6668', '6669', '6670', '6672', '6674', '8011', '8016', '8021', '8028', '8033', '8039', '8046', '8070', '8072', '8081', '8101', '8103', '8104', '8105', '8110', '8112', '8114', '8131', '8150', '8163', '8201', '8210', '8213', '8215', '8222', '8249', '8261', '8271', '8341', '8367', '8374', '8404', '8411', '8422', '8429', '8442', '8443', '8454', '8462', '8463', '8464', '8466', '8467', '8473', '8478', '8481', '8482', '8499', '8926', '8940', '8996', '9802', '9902', '9904', '9905', '9906', '9907', '9908', '9910', '9911', '9912', '9914', '9917', '9919', '9921', '9924', '9925']
    #cus_stockarray_1 = ['5876', '5880', '5907', '6005', '6024', '6108', '6112', '6115', '6116', '6120', '6128', '6133', '6136', '6139', '6141', '6142', '6152', '6155', '6164', '6165', '6166', '6168', '6172', '6176', '6177', '6183', '6184', '6189', '6191', '6192', '6196', '6197', '6201', '6202', '6205', '6206', '6209', '6213', '6214', '6215', '6216', '6224', '6226', '6230', '6235', '6239', '6243', '6251', '6257', '6269', '6271', '6277', '6278', '6281', '6282', '6283', '6285', '6288', '6289', '6409', '6412', '6414', '6415', '6416', '6431', '6442', '6443', '6449', '6451', '6452', '6456', '6477', '6504', '6505', '6525', '6531', '6533', '6541', '6552', '6558', '6573', '6579', '6581', '6591', '6605', '6655', '6666', '6668', '6669', '6670', '6672', '6674', '8011', '8016', '8021', '8028', '8033', '8039', '8046', '8070', '8072', '8081', '8101', '8103', '8104', '8105', '8110', '8112', '8114', '8131', '8150', '8163', '8201', '8210', '8213', '8215', '8222', '8249', '8261', '8271', '8341', '8367', '8374', '8404', '8411', '8422', '8429', '8442', '8443', '8454', '8462', '8463', '8464', '8466', '8467', '8473', '8478', '8481', '8482', '8499', '8926', '8940', '8996', '9802', '9902', '9904', '9905', '9906', '9907', '9908', '9910', '9911', '9912', '9914', '9917', '9919', '9921', '9924', '9925']

    #cus_stockarray_1 = ['8249', '8261', '8271', '8341', '8367', '8374', '8404', '8411', '8422', '8429', '8442', '8443', '8454', '8462', '8463', '8464', '8466', '8467', '8473', '8478', '8481', '8482', '8499', '8926', '8940', '8996', '9802', '9902', '9904', '9905', '9906', '9907', '9908', '9910', '9911', '9912', '9914', '9917', '9919', '9921', '9924', '9925']
    #cus_stockarray_C = ['8249', '8422', '8481', '8926', '9924', '9925']
    cus_stockarray_filter = []
    cus_stockarray_filter_1 = []
    cus_stockarray_1 = cus_stockarray_A + cus_stockarray_B + cus_stockarray_C + cus_stockarray_D + cus_stockarray_E
    cus_stockarray   = cus_stockarray_1
    for i in range(len(cus_stockarray)):
        print("-----------------------------")
        print("Current Stock is:", cus_stockarray[i])
        print("Count:", i)
        TaiwanStockPrice = Load.FinData(
            dataset = 'TaiwanStockPrice',
            select = cus_stockarray[i],
            #select = ['1315'],
            date = date3 )

        TaiwanStockStockDividend = Load.FinData(
            dataset = 'TaiwanStockStockDividend',
            select = cus_stockarray[i],
            #select = ['1315'],
            date = date3)
        #print(TaiwanStockPrice[:5])

        if not len(TaiwanStockPrice):
            print('The data is empty')
            continue
            
        if not len(TaiwanStockStockDividend):
           print('The data of Dividend is empty')
           continue

        #Dividend yield
        print(TaiwanStockStockDividend)
        print('The Dividend is:')
        print(TaiwanStockStockDividend.iloc[0,1])
        print('The Present price is:')
        print(TaiwanStockPrice.iloc[-1,3])

        TaiwanStockDividendYield =TaiwanStockStockDividend.iloc[0,1]/TaiwanStockPrice.iloc[-1,3]
        print(TaiwanStockDividendYield)

        TaiwanStockPrice_str_to_int = (pd.to_numeric(TaiwanStockPrice.iloc[:,0])/1000).astype(int)
        TaiwanStockPrice_str_to_int_present = (pd.to_numeric(TaiwanStockPrice.iloc[-1,0])/1000).astype(int)
        print(TaiwanStockPrice_str_to_int_present)
        print("The max volume is ")
        print(TaiwanStockPrice_str_to_int.max())
        print("The min volume is ")
        print(TaiwanStockPrice_str_to_int.min())
        print("Today Volume is")
        print(TaiwanStockPrice_str_to_int_present)
        #print(TaiwanStockPrice.sort_values(by=["Trading_Volume"],ascending=True))
        TaiwanStockPrice_str_to_int_sort = TaiwanStockPrice_str_to_int.sort_values(ascending=False)
        TaiwanStockPrice_str_to_int_sort.reset_index(drop = True, inplace=True)
        #print(TaiwanStockPrice_str_to_int_sort)

        if TaiwanStockPrice_str_to_int_sort[0] > TaiwanStockPrice_str_to_int_sort[1] * 1.5 and TaiwanStockPrice_str_to_int_present == TaiwanStockPrice_str_to_int.max():
          print("Max is bigger than Second 2 times, Stock ID is :",cus_stockarray[i])
          print("Today is max volume and Max is bigger than second 2 times")
          cus_stockarray_filter = cus_stockarray[i]
        if TaiwanStockPrice_str_to_int_present == TaiwanStockPrice_str_to_int.max():
          print("Today is max volume in four mouths")
          cus_stockarray_filter_1 = cus_stockarray[i]
        
    #stockarray_max1 = cus_stockarray_filter
    #stockarray_max2 = cus_stockarray_filter_1
    return 

'''
print('load 財報 FinancialStatements {} '.format(TaiwanStockInfo.loc[_index,'stock_id']))
TaiwanStockFinancialStatements = Load.FinData(
        dataset = 'FinancialStatements',
        select = TaiwanStockInfo.loc[9010,'stock_id'],
        date = date3)
print( TaiwanStockFinancialStatements[:5] )
# transpose
data = Load.transpose(TaiwanStockFinancialStatements)
'''
# transpose

#
'''
TaiwanStockStockDividend = Load.FinData(
        dataset = 'TaiwanStockStockDividend',
        select = ['2204'],
        date = date3)

#print( TaiwanStockStockDividend['Cash_dividend'] )
#print((pd.to_numeric(TaiwanStockStockDividend['Cash_dividend']).tail(1)).astype(float))
TaiwanStockPrice = Load.FinData(
        dataset = 'TaiwanStockPrice',
        select = ['2204'],
        date = date3)
print(TaiwanStockPrice.iloc[:5])
print(TaiwanStockPrice.shape)
print(TaiwanStockPrice.iloc[-1,3])
print("----")
if len(TaiwanStockStockDividend):
  print(TaiwanStockStockDividend.iloc[0,1])
else:
  print("fuck")
#Dividend yield
if len(TaiwanStockStockDividend):
  TaiwanStockDividendYield =TaiwanStockStockDividend.iloc[0,1]/TaiwanStockPrice.iloc[-1,3]
  if TaiwanStockDividendYield > 0.05 :
    print(TaiwanStockDividendYield)
  else:
    print("Not good")
'''
'''
print('load 借卷融資 TaiwanStockMarginPurchaseShortSale {} '.format(TaiwanStockInfo.loc[_index,'stock_id']))
TaiwanStockMarginPurchaseShortSale = Load.FinData(
        dataset = 'TaiwanStockMarginPurchaseShortSale',
        select = TaiwanStockInfo.loc[_index,'stock_id'],
        date = date3)
print( TaiwanStockMarginPurchaseShortSale[:5] )

print('load 外資買賣 InstitutionalInvestorsBuySell {} '.format(TaiwanStockInfo.loc[_index,'stock_id']))
InstitutionalInvestorsBuySell = Load.FinData(
        dataset = 'InstitutionalInvestorsBuySell',
        select = TaiwanStockInfo.loc[_index,'stock_id'],
        date = date3)
print( InstitutionalInvestorsBuySell[:5] )

print('load 外資持股 Shareholding {} '.format(TaiwanStockInfo.loc[_index,'stock_id']))
Shareholding = Load.FinData(
        dataset = 'Shareholding',
        select = TaiwanStockInfo.loc[_index,'stock_id'],
        date = date3)
print( Shareholding[:5] )

print('load 資產負債表 BalanceSheet {} '.format(TaiwanStockInfo.loc[_index,'stock_id']))
BalanceSheet = Load.FinData(
        dataset = 'BalanceSheet',
        select = '2317',
        date = date3)
print( BalanceSheet[:5] )
data = Load.transpose(BalanceSheet)

print('load 股權分散表 TaiwanStockHoldingSharesPer {} '.format(TaiwanStockInfo.loc[_index,'stock_id']))
TaiwanStockHoldingSharesPer = Load.FinData(
        dataset = 'TaiwanStockHoldingSharesPer',
        select = TaiwanStockInfo.loc[_index,'stock_id'],
        date = date3)
print( TaiwanStockHoldingSharesPer[:5] )

print('load 月營收 TaiwanStockMonthRevenue {} '.format(TaiwanStockInfo.loc[_index,'stock_id']))
TaiwanStockMonthRevenue = Load.FinData(
        dataset = 'TaiwanStockMonthRevenue',
        select = TaiwanStockInfo.loc[_index,'stock_id'],
        date = date3)
print( TaiwanStockMonthRevenue[:5] )


print('load 選擇權 TaiwanOption ')
TaiwanOption = Load.FinData(
        dataset = 'TaiwanOption',
        select = 'OCO',
        date = '2019-09-05',)
print( TaiwanOption[:5] )


print('load 期貨 TaiwanFutures ')
TaiwanFutures = Load.FinData(
        dataset = 'TaiwanFutures',
        select = 'MTX',
        date = '2019-09-02')
print( TaiwanFutures[:5] )

#---------------------------------------------------------------
print('load USStockInfo')
USStockInfo = Load.FinData(dataset = 'USStockInfo')
print( USStockInfo[:5] )

print('load USStockPrice {} '.format(USStockInfo.loc[20,'stock_id']))
USStockPrice = Load.FinData(
        dataset = 'USStockPrice',
        select = USStockInfo.loc[20,'stock_id'],
        date = date)
print( USStockPrice[:5] )

print('load 財報 FinancialStatements {} '.format(USStockInfo.loc[15,'stock_id']))
USStockFinancialStatements = Load.FinData(
        dataset = 'FinancialStatements',
        select = USStockInfo.loc[15,'stock_id'],
        date = date3)
print(USStockFinancialStatements)
#---------------------------------------------------------------
print('load JapanStockInfo')
JapanStockInfo = Load.FinData(dataset = 'JapanStockInfo')
print( JapanStockInfo[:5] )

print('load JapanStockPrice {} '.format(JapanStockInfo.loc[2,'stock_id']))
JapanStockPrice = Load.FinData(
        dataset = 'JapanStockPrice',
        select = JapanStockInfo.loc[2,'stock_id'],
        date = date)
print( JapanStockPrice[:5] )
#---------------------------------------------------------------
print('load UKStockInfo')
UKStockInfo = Load.FinData(dataset = 'UKStockInfo')
print( UKStockInfo[:5] )

print('load UKStockPrice {} '.format(UKStockInfo.loc[2,'stock_id']))
UKStockPrice = Load.FinData(
        dataset = 'UKStockPrice',
        select = UKStockInfo.loc[200,'stock_id'],
        date = date)
print( UKStockPrice[:5] )
#---------------------------------------------------------------
print('load EuropeStockInfo')
EuropeStockInfo = Load.FinData(dataset = 'EuropeStockInfo')
print( EuropeStockInfo[:5] )

print('load EuropeStockPrice {} '.format(EuropeStockInfo.loc[2,'stock_id']))
EuropeStockPrice = Load.FinData(
        dataset = 'EuropeStockPrice',
        select = EuropeStockInfo.loc[2,'stock_id'],
        date = date)
print( EuropeStockPrice[:5] )
#---------------------------------------------------------------
print('load ExchangeRate list')
ExchangeRate_list = Load.FinDataList(dataset = 'ExchangeRate')
print( ExchangeRate_list[:5] )

print('load ExchangeRate {}'.format(ExchangeRate_list[3]))
ExchangeRate = Load.FinData(
        dataset = 'ExchangeRate',
        select = ExchangeRate_list[3],
        date = date)
print( ExchangeRate[:5] )

#---------------------------------------------------------------
print('load InstitutionalInvestors list')
InstitutionalInvestors_list = Load.FinDataList(dataset = 'InstitutionalInvestors')
print( InstitutionalInvestors_list[:5] )

print('load InstitutionalInvestors {}'.format(InstitutionalInvestors_list[3]))
InstitutionalInvestors = Load.FinData(
        dataset = 'InstitutionalInvestors',
        select = InstitutionalInvestors_list[1],
        date = date)
print( InstitutionalInvestors[:5] )

#---------------------------------------------------------------
print('load InterestRate list')
InterestRate_list = Load.FinDataList(dataset = 'InterestRate')
print( InterestRate_list[:5] )

print('load InterestRate {}'.format(InstitutionalInvestors_list[3]))
InterestRate = Load.FinData(
        dataset = 'InterestRate',
        select = InterestRate_list[5],
        date = date2)
print( InterestRate[:5] )

#---------------------------------------------------------------
print('load GovernmentBonds list')
GovernmentBonds_list = Load.FinDataList(dataset = 'GovernmentBonds')
print( GovernmentBonds_list[:5] )

print('load GovernmentBonds {}'.format(GovernmentBonds_list[3]))
GovernmentBonds = Load.FinData(
        dataset = 'GovernmentBonds',
        select = GovernmentBonds_list[3],
        date = date)
print( GovernmentBonds[:5] )

#---------------------------------------------------------------
print('load CrudeOilPrices list')
CrudeOilPrices_list = Load.FinDataList(dataset = 'CrudeOilPrices')
print( CrudeOilPrices_list[:5] )

print('load CrudeOilPrices {}'.format(CrudeOilPrices_list[1]))
CrudeOilPrices = Load.FinData(
        dataset = 'CrudeOilPrices',
        select = CrudeOilPrices_list[1],
        date = date)
print( CrudeOilPrices[:5] )

#---------------------------------------------------------------
print('load RawMaterialFuturesPrices list')
RawMaterialFuturesPrices_list = Load.FinDataList(dataset = 'RawMaterialFuturesPrices')
print( RawMaterialFuturesPrices_list[:5] )

print('load RawMaterialFuturesPrices {}'.format(RawMaterialFuturesPrices_list[3]))
RawMaterialFuturesPrices = Load.FinData(
        dataset = 'RawMaterialFuturesPrices',
        select = RawMaterialFuturesPrices_list[3],
        date = date)
print( RawMaterialFuturesPrices[:5] )
#---------------------------------------------------------------
print('load GoldPrice ')
GoldPrice = Load.FinData(
        dataset = 'GoldPrice',
        date = date)
print( GoldPrice[:5] )
#---------------------------------------------------------------
print('load CurrencyCirculation list')
CurrencyCirculation_list = Load.FinDataList(dataset = 'CurrencyCirculation')
print( CurrencyCirculation_list[:5] )

print('load CurrencyCirculation ')
CurrencyCirculation = Load.FinData(
        dataset = 'CurrencyCirculation',
        select = CurrencyCirculation_list[1],
        date = date)
print( CurrencyCirculation[:5] )
'''
