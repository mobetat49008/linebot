from flask import Flask, request, abort

from linebot import (
    LineBotApi, WebhookHandler
)
from linebot.exceptions import (
    InvalidSignatureError
)
from linebot.models import *
import os
import schedule
import time
import sys
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
import atexit
from FinMind.example import demo
sys.path.append("../wootalk_comment")
import main
import threading

#import ThreadClass

app = Flask(__name__)
userid = "U43fae8db367a041906213d30b5fd478f"
# Channel Access Token
# Test
line_bot_api = LineBotApi('CQYLjcDK0dY8uKymQcg1cpB4KtFtdsyA1tHvGA4wE+tbJTc+Mi+Yc7apE0/+uFEtP8tKclGokqmQpo2IERiA35P0EwmNWQ+V8nyNXBGk8pYfENI125wboqU3EU+cHElCzdmovIS8+3OLgZBO40LXPAdB04t89/1O/w1cDnyilFU=')
# Channel Secret
handler = WebhookHandler('0ae71507650ca0eebf1561a66e693178')

threads = []

# 子執行緒的工作函數
class MyThread(threading.Thread):
    def __init__(self,func):
        super(MyThread, self).__init__()
        self.func = func
 
    def run(self):
        time.sleep(2)
        self.result = self.func
 
    def get_result(self):
        threading.Thread.join(self) # 等待线程执行完毕
        try:
            return self.result
        except Exception:
            return None

  
# 監聽所有來自 /callback 的 Post Request
@app.route("/callback", methods=['POST'])
def callback():
    # get X-Line-Signature header value
    signature = request.headers['X-Line-Signature']
    # get request body as text
    body = request.get_data(as_text=True)
    app.logger.info("Request body: " + body)
    print("Enter while loop12")
    # handle webhook body
    try:
        handler.handle(body, signature)
    except InvalidSignatureError:
        abort(400)
    return 'OK'

# 處理訊息
@handler.add(MessageEvent, message=TextMessage)
def handle_message(event):
    myText=event.message.text;
    global mode
    stockarray_max1   = []
    stockarray_max2   = []

    content = ''
    print("Start if, myText=",myText)
    if myText=='ben':
        message = TextSendMessage(text="聖約翰")
        line_bot_api.reply_message(event.reply_token, message)
    elif myText=='stop reply':
        mode = 1
        message = TextSendMessage(text="閉嘴中...")
        line_bot_api.reply_message(event.reply_token, message)
    elif myText=='start reply':
        mode = 2
        message = TextSendMessage(text="張嘴中...")
        line_bot_api.reply_message(event.reply_token, message)
    elif myText=='scan':
        stockarray_max1, stockarray_max2 = demo.test()
        push_result(stockarray_max1,stockarray_max2)
    elif myText=='knock':

        task = MyThread(main.knock())
        task.start()
        if task.get_result()==True:
            message = TextSendMessage(text="敲敲杯")
            line_bot_api.push_message(userid, message)      
    else :
        if mode ==2 or mode ==0:
            message = TextSendMessage(text=event.message.text)
            line_bot_api.reply_message(event.reply_token, message)


def push_result(arr1,arr2):
    
    if arr1[0] != "0":
        print("今日爆最大量且最大量為次量兩倍以上")
        print(arr1)
        content = "今日是最大量且最大量為次量兩倍以上"
        for i in range(len(arr1)):
            content += "\n" + "\'" +arr1[i]  + "\'" + "\n"
        message = TextSendMessage(text=content)
        line_bot_api.push_message(userid, message)
    else:
        message = TextSendMessage(text="今日無爆兩倍量")
        line_bot_api.push_message(userid, message)
    
    content = ''
    
    if arr2[0] != "0":
        print("今日爆最大量")
        print(arr2)
        content = "今日是最大量"
        for i in range(len(arr2)):
            content += "\n" + "\'" +arr2[i]  + "\'" + "\n"
        message = TextSendMessage(text=content)
        line_bot_api.push_message(userid, message)
    else:
        message = TextSendMessage(text="今日不是最大量")
        line_bot_api.push_message(userid, message)
    
def job():
    stockarray   = []
    stockarray_1   = []
    stockarray_2   = []
    stockarray_3   = []
    print("I'm working...")
    
    stockarray, stockarray_1 = demo.test()

    if stockarray[0]!= "0" or stockarray_1[0]!= "0":
        push_result(stockarray,stockarray_1)   
    else:
        message = TextSendMessage(text="殖利率>5% & 成交量>1000 無更新")
        line_bot_api.push_message(userid, message)

    stockarray_2,stockarray_3 = demo.scan20()
    if stockarray_2[0]!= "0" or stockarray_3[0]!= "0":
        push_result(stockarray_2,stockarray_3)
    else:
        message = TextSendMessage(text="前20大權值無更新")
        line_bot_api.push_message(userid, message)

  
if __name__ == "__main__":
    mode = 0 #0:init, 1:stop, 2:start 
    threads = []
    port = int(os.environ.get('PORT', 5000))
    # create schedule for printing time
    scheduler = BackgroundScheduler()
    scheduler.start()
    scheduler.add_job(job,'cron', day_of_week='mon-fri', hour='16', minute="00", second="0",id='my_job_id',misfire_grace_time=30)
    scheduler.remove_job('my_job_id')
    # Shut down the scheduler when exiting the app
    #atexit.register(lambda: scheduler.shutdown())
    mode = 1


    app.run(host='0.0.0.0', port=port)

