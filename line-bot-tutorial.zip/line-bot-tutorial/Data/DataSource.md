# Data Source


* Taiwan Stock Info : `http://www.twse.com.tw`
* Taiwan Stock Price : 
	* `http://www.twse.com.tw`
	* `https://www.tpex.org.tw`
* Taiwan Balance Sheet : `http://mops.twse.com.tw/mops/web/index`
* Taiwan Stock Shareholding : `http://www.twse.com.tw`
* Taiwan Stock Institutional Investors Buy Sell : `https://www.tpex.org.tw`
* Taiwan Stock Financial Statements : `http://mops.twse.com.tw/mops/web/index`
* Taiwan Stock Holding Shares Per : `https://www.tdcc.com.tw/portal`
* Taiwan Stock Margin Purchase Short Sale : `http://www.twse.com.tw`

* UK Stock Info : `https://business.nasdaq.com`
* UK Stock Price : `yahoo finance api`

* US Stock Info : `https://business.nasdaq.com`
* US Financial Statements : `https://www.macrotrends.net`
* US Stock Price : `yahoo finance api`

* Japan Stock Info : `https://www.marketwatch.com`
* Japan Stock Price : `yahoo finance api`

* Europe Stock Info : `https://business.nasdaq.com`
* Europe Stock Price : `yahoo finance api`

* Exchange Rate : `https://www.ofx.com/en-au`
* Gold Price : `https://www.gold.org`
* Government Bonds : `https://www.investing.com`
* Interest Rate : `https://www.investing.com`
* Crude Oil Prices :`https://www.eia.gov`
* Raw Material Futures Prices : `https://www.investing.com`

