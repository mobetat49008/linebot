#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug  2 00:11:48 2018

@author: linsam
"""

# __init__
